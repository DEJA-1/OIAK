package numberSystem.base

import numberSystem.NumberSystem

class NumberBaseSystem(val value: String, val base: Int) : NumberSystem<String>(value, base)